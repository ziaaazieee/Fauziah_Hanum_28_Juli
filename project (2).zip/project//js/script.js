document.getElementById("bar_key").addEventListener('submit', function(event) {
        event.preventDefault(); //Mencegah form untuk submit secara default
    
        //Mendapatkan nilai username dan password
        var username = document.getElementById('username').value;
        var password = document.getElementById('password').value;
        var erormessage = document.getElementById('eror-message');
     
        //Validasi Username dan password
        if (username === '' || password === '') {
            erormessage.textContent = 'isi woyyyy!!';
        }
    });